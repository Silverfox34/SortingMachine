print("hello there from inside ".._PROGNAME)
print(...)
print"bye!"

print("hello again from inside "..arg[0])
for i=0,arg.n do
	print(i,arg[i])
end
print"bye!"
