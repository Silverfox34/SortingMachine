

function main()
    
    local array = getRandomArray(MathPow(2,16))
    
    local end_element = #array
    local bef = os.time()
    quickSort(array, 0, end_element)
    local after = os.time()
    --printArray(array)
    print("TIME: ", after-bef)
end

function quickSort(array, begin_element, end_element) 
    local partitionIndex
    if (begin_element < end_element) 
    then
        partitionIndex = partition(array, begin_element, end_element);

        quickSort(array, begin_element, partitionIndex-1);
        quickSort(array, partitionIndex+1, end_element);
    end

    
    
end

function partition(array, begin_element, end_element)
    local pivot = begin_element
    local j, tmp
    
    for j=begin_element+1, end_element, 1
    do
        if(array[j] < array[begin_element])
        then
            tmp = array[begin_element];
            array[begin_element] = array[j];
            array[j] = tmp;
        end
    end

    tmp = array[begin_element];
    array[begin_element] = array[pivot];
    array[pivot] = tmp;

    return pivot;
    
    
end
    
    



function printArray(array)
    local i
    for i=0, #array, 1
    do
        print(array[i])
    end
end

function MathPow(number, exponent)
    local erg = number
    local i
    for i = 1, exponent-1, 1
    do
        number = number * erg
    end
    
    return number
end

function getRandomArray(size)
    math.randomseed(os.time())
    local array = {}
    local i
    for i=0, size-1, 1
    do
        
        array[i] = math.floor(math.random()*1000)
    end

    return array
end

main()
