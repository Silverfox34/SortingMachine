To make an .exe file from a .lua file, enter cmd or powershell and use the snytax:

glue.exe srlua.exe [my_input_file].lua [my_output_file].exe

It will make an executable right where you are